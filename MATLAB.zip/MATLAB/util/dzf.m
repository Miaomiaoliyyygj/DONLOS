function v=dzf(u)

v = u(:,:,[2:end 1]) - u(:,:,:);
