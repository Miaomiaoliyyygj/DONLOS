function v=dxf(u)

v = u([2:end 1],:,:) - u(:,:,:);
