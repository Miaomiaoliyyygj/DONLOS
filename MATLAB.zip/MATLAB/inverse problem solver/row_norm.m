function y = row_norm( u )
y = sqrt(u(:,1).^2 + u(:,2).^2 + u(:,3).^2);
end

